import 'package:flutter/material.dart';

class AppColors {
  static const primaryGreen = Color(0xFF4CAF50); // verde principal
  static const darkGreen = Color(0xFF388E3C);    // verde escuro
  static const lightGreen = Color(0xFFC8E6C9);   // verde claro
}
